──────────────────────────────────────────────────────────
CONTACT INFORMATION
──────────────────────────────────────────────────────────

For support, feedback, or any inquiries regarding this mod, feel free to reach out:

Author: StaticMdz
Discord: staticm223
Discord server: https://discord.gg/JqFBRYJvEx

──────────────────────────────────────────────────────────

Mod Name: More Harvester Capacity [MHC]

Description:
──────────────────────────────────────────────────────────
This mod transforms your Farming Simulator experience by
increasing the storage capacity of all harvesters by 10x.
Say goodbye to frequent unloading trips and maximize your
efficiency in the field. With expanded stock amounts,
you can focus on the harvest without interruptions, making
your farming operations smoother and more productive.

Pair it with the Increase Field Yield [IFY] mod for the ultimate 
farming efficiency! Harvest bigger yields effortlessly 
as your enhanced harvester capacity keeps up with the boosted
crop output, making every farming session more rewarding.

──────────────────────────────────────────────────────────
INSTALLATION INSTRUCTIONS
──────────────────────────────────────────────────────────

[ Step 1 ]
Go to Your Mods Directory
──────────────────────────────────────────────────────────
Locate your Farming Simulator 25 Documents folder

Example: C:\Users\[NAME]\Documents\My Games\FarmingSimulator2025

[ Step 2 ]
Install the Mod
──────────────────────────────────────────────────────────

Navigate to the mods folder, then drag and drop FS25_IFY.zip

Then go back to the C:\Users\[NAME]\Documents\My Games\FarmingSimulator2025
folder and drag and drop the modSettings folder in there

This will install the mod and activate the increased yields for your crops.
──────────────────────────────────────────────────────────
And just like that, you're all done! Enjoy the Mod!
Experience faster and more rewarding farming as you enjoy higher yields and
a more relaxed gameplay experience.