FasterProductions = {}

function FasterProductions:onTimescaleChanged()
	self.minuteFactorTimescaled = self.mission:getEffectiveTimeScale() / 1000 / 60 / self.mission.environment.daysPerPeriod -- now its really "per month" instead of "per day"
end

function FasterProductions:load(success, components, xmlFile, key, customEnv, i3dMappings)
	if success then
		for _, production in ipairs(self.productions) do
			if production.outputs[1] ~= nil then
				local origProd = production.cyclesPerHour * production.outputs[1].amount
				--printf("Increasing production cycles for production %s", production.name)
				production.cyclesPerHour = math.ceil(production.cyclesPerHour * 50)
				production.cyclesPerMinute = production.cyclesPerHour / 60
				production.cyclesPerMonth = production.cyclesPerHour * 24 -- per day, actually
			end
		end
	end
	return success
end

local function appendedFunction(oldFunc, newFunc)
	if oldFunc ~= nil then
		return function (self, ...)
			retValue = oldFunc(self, ...)
			return newFunc(self, retValue, ...)
		end
	else
		return newFunc
	end
end

ProductionPoint.onTimescaleChanged = Utils.overwrittenFunction(ProductionPoint.onTimescaleChanged, FasterProductions.onTimescaleChanged)
ProductionPoint.load = appendedFunction(ProductionPoint.load, FasterProductions.load)
