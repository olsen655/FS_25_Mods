AbstractTurn = {}
AbstractTurn_mt = {__index = AbstractTurn}

function AbstractTurn:update(dt)
end

function AbstractTurn:getWayPoints()
end

function AbstractTurn:checkValidity(turnParameters)
end