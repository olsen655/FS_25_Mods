IFY = {};

function IFY:loadMap(name)
    IFY:ApplySettings();
end;

function IFY:mouseEvent(posX, posY, isDown, isUp, button)
end;

function IFY:keyEvent(unicode, sym, modifier, isDown)
end;

function IFY:update(dt)
end;

function IFY:draw(dt)
end;

function IFY:ApplySettings()
    -- Integrated fruit type data directly in Lua table format
    local fruitTypes = {
        { name = "WHEAT", seedUsagePerSqm = 0.040000, literPerSqm = 4.670000, defaultSeedUsagePerSqm = 0.050000, defaultLiterPerSqm = 0.890000 },
        { name = "BARLEY", seedUsagePerSqm = 0.040000, literPerSqm = 4.880000, defaultSeedUsagePerSqm = 0.026500, defaultLiterPerSqm = 0.960000 },
        { name = "OAT", seedUsagePerSqm = 0.040000, literPerSqm = 4.710000, defaultSeedUsagePerSqm = 0.050000, defaultLiterPerSqm = 0.570000 },
        { name = "CANOLA", seedUsagePerSqm = 0.020000, literPerSqm = 4.740000, defaultSeedUsagePerSqm = 0.020000, defaultLiterPerSqm = 0.580000 },
        { name = "MAIZE", seedUsagePerSqm = 0.040000, literPerSqm = 4.760000, defaultSeedUsagePerSqm = 0.040000, defaultLiterPerSqm = 0.920000 },
        { name = "GRASS", seedUsagePerSqm = 0.012000, literPerSqm = 8.760000, defaultSeedUsagePerSqm = 0.012000, defaultLiterPerSqm = 4.370000 },
        { name = "SUNFLOWER", seedUsagePerSqm = 0.030000, literPerSqm = 4.500000, defaultSeedUsagePerSqm = 0.030000, defaultLiterPerSqm = 0.520000 },
        { name = "SOYBEAN", seedUsagePerSqm = 0.030000, literPerSqm = 4.350000, defaultSeedUsagePerSqm = 0.030000, defaultLiterPerSqm = 0.450000 },
        { name = "POTATO", seedUsagePerSqm = 0.400000, literPerSqm = 12.300000, defaultSeedUsagePerSqm = 0.380000, defaultLiterPerSqm = 4.130000 },
        { name = "SUGARBEET", seedUsagePerSqm = 0.040000, literPerSqm = 17.340000, defaultSeedUsagePerSqm = 0.040000, defaultLiterPerSqm = 5.780000 },
        { name = "RICE", seedUsagePerSqm = 0.020000, literPerSqm = 4.760000, defaultSeedUsagePerSqm = 0.015625, defaultLiterPerSqm = 0.660000 },
        { name = "RICELONGGRAIN", seedUsagePerSqm = 0.020000, literPerSqm = 4.760000, defaultSeedUsagePerSqm = 0.050000, defaultLiterPerSqm = 0.900000 },
        { name = "SUGARCANE", seedUsagePerSqm = 1.200000, literPerSqm = 34.020000, defaultSeedUsagePerSqm = 1.200000, defaultLiterPerSqm = 11.340000 },
        { name = "COTTON", seedUsagePerSqm = 0.040000, literPerSqm = 4.491000, defaultSeedUsagePerSqm = 0.050000, defaultLiterPerSqm = 0.497000 },
        { name = "SORGHUM", seedUsagePerSqm = 0.020000, literPerSqm = 4.460000, defaultSeedUsagePerSqm = 0.020000, defaultLiterPerSqm = 0.820000 },
        { name = "GRAPE", seedUsagePerSqm = 0.020000, literPerSqm = 4.760000, defaultSeedUsagePerSqm = 0.020000, defaultLiterPerSqm = 0.920000 },
        { name = "OLIVE", seedUsagePerSqm = 0.020000, literPerSqm = 4.760000, defaultSeedUsagePerSqm = 0.020000, defaultLiterPerSqm = 0.920000 },
        { name = "BEETROOT", seedUsagePerSqm = 0.020000, literPerSqm = 4.760000, defaultSeedUsagePerSqm = 0.020000, defaultLiterPerSqm = 0.920000 },
        { name = "CARROT", seedUsagePerSqm = 0.040000, literPerSqm = 7.500000, defaultSeedUsagePerSqm = 0.040000, defaultLiterPerSqm = 2.500000 },
        { name = "PARSNIP", seedUsagePerSqm = 0.020000, literPerSqm = 4.760000, defaultSeedUsagePerSqm = 0.020000, defaultLiterPerSqm = 0.920000 },
        { name = "GREENBEAN", seedUsagePerSqm = 0.020000, literPerSqm = 4.760000, defaultSeedUsagePerSqm = 0.020000, defaultLiterPerSqm = 0.920000 },
        { name = "PEA", seedUsagePerSqm = 0.020000, literPerSqm = 4.760000, defaultSeedUsagePerSqm = 0.020000, defaultLiterPerSqm = 0.920000 }
    };

    -- Integrated spray type data directly in Lua table format
    local sprayTypes = {
        { name = "FERTILIZER", litersPerSecond = 0.006000, defaultLitersPerSecond = 0.006000 },
        { name = "LIQUIDFERTILIZER", litersPerSecond = 0.008100, defaultLitersPerSecond = 0.008100 },
        { name = "MANURE", litersPerSecond = 0.400000, defaultLitersPerSecond = 0.400000 },
        { name = "LIQUIDMANURE", litersPerSecond = 0.400000, defaultLitersPerSecond = 0.400000 },
        { name = "DIGESTATE", litersPerSecond = 0.400000, defaultLitersPerSecond = 0.400000 },
        { name = "LIME", litersPerSecond = 0.090000, defaultLitersPerSecond = 0.090000 },
        { name = "HERBICIDE", litersPerSecond = 0.008100, defaultLitersPerSecond = 0.008100 }
    };

    -- Apply fruit types
    for _, fruit in pairs(fruitTypes) do
        local ft = g_fruitTypeManager:getFruitTypeByName(fruit.name);

        if ft ~= nil then
            ft.seedUsagePerSqm = fruit.seedUsagePerSqm;
            ft.literPerSqm = fruit.literPerSqm;
            print(string.format("Apply new values for FruitType name - %s, seedUsagePerSqm - %.6f, literPerSqm - %.6f", fruit.name, fruit.seedUsagePerSqm, fruit.literPerSqm));
        end;
    end;

    -- Apply spray types
    for _, spray in pairs(sprayTypes) do
        local sp = g_sprayTypeManager:getSprayTypeByName(spray.name);

        if sp ~= nil then
            sp.litersPerSecond = spray.litersPerSecond;
            print(string.format("Apply new values for SprayType name - %s, litersPerSecond - %.6f", spray.name, spray.litersPerSecond));
        end;
    end;
end;

addModEventListener(IFY);